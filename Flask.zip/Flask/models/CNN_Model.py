#!/usr/bin/env python
# coding: utf-8

# In[1]:


get_ipython().system('pip install pandas numpy scikit-learn tensorflow')
get_ipython().system('pip install openpyxl')


# In[2]:


import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, Conv1D, GlobalMaxPooling1D, Dense


# In[6]:


data = pd.read_csv("C:/Users/Harnoor Singh/Desktop/Study Material/MSc CSNL/Summer Project/train_data.csv")
for col in data.columns:
    print(col)


# In[7]:


data.head()


# In[8]:


#data = data.drop(['Unnamed: 0.2','Unnamed: 0','Unnamed: 0.1','Unnamed: 0.1.1','Unnamed: 0.1.1.1','Unnamed: 0.1.1.1.1'],axis=1)


# In[9]:


data.head()
# data.reset_index()


# ## Pre Processing:

# ##### 1. Text Lowercasing:

# In[10]:


get_ipython().system('pip install nltk')


# In[11]:


import nltk
nltk.download('stopwords')
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
import string

# 1. Text Lowercasing
data['statement'] = data['statement'].str.lower()

# 2. Removing Punctuation
data['statement'] = data['statement'].str.replace('[{}]'.format(string.punctuation), '')

# # 3. Stopword Removal
# stop_words = set(stopwords.words('english'))
# data['statement'] = data['statement'].apply(lambda x: [word for word in x if word.lower() not in stop_words])

# # 4. Handling Numbers and Special Characters (Optional)
# data['statement'] = data['statement'].apply(lambda x: [word for word in x if not word.isdigit()])

# # 5. Handling URLs and Mentions (Optional)
# data['statement'] = data['statement'].apply(lambda x: [word for word in x if not word.startswith(('http://', 'https://', '@'))])

# Print the preprocessed data
print(data['statement'])


# In[12]:


data


# In[ ]:





# In[ ]:





# In[13]:


texts = data['statement'].astype(str)
labels = data['sentiment']

label_encoder = LabelEncoder()
labels = label_encoder.fit_transform(labels)

data.head()


# In[14]:


# Test model 1:


# train_texts, test_texts, train_labels, test_labels = train_test_split(texts, labels, test_size=0.2, random_state=42)

# tokenizer = Tokenizer(num_words=10000)
# tokenizer.fit_on_texts(train_texts)

# train_sequences = tokenizer.texts_to_sequences(train_texts)
# test_sequences = tokenizer.texts_to_sequences(test_texts)

# max_sequence_length = max(len(seq) for seq in train_sequences)
# train_data = pad_sequences(train_sequences, maxlen=max_sequence_length)
# test_data = pad_sequences(test_sequences, maxlen=max_sequence_length)

# model = Sequential()
# model.add(Embedding(10000, 128, input_length=max_sequence_length))
# model.add(Conv1D(128, 5, activation='relu'))
# model.add(GlobalMaxPooling1D())
# model.add(Dense(1, activation='sigmoid'))

# model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# model.fit(train_data, train_labels, epochs=10, batch_size=16, validation_data=(test_data, test_labels))

# _, accuracy = model.evaluate(test_data, test_labels)
# print('Accuracy:', accuracy)


# In[15]:


def predict():
    train_texts, test_texts, train_labels, test_labels = train_test_split(texts, labels, test_size=0.2, random_state=42)

    tokenizer = Tokenizer(num_words=10000)
    tokenizer.fit_on_texts(train_texts)

    train_sequences = tokenizer.texts_to_sequences(train_texts)
    test_sequences = tokenizer.texts_to_sequences(test_texts)

    max_sequence_length = max(len(seq) for seq in train_sequences)
    train_data = pad_sequences(train_sequences, maxlen=max_sequence_length)
    test_data = pad_sequences(test_sequences, maxlen=max_sequence_length)

    model = Sequential()
    model.add(Embedding(10000, 128, input_length=max_sequence_length))
    model.add(Conv1D(128, 5, activation='relu'))
    model.add(GlobalMaxPooling1D())
    model.add(Dense(1, activation='sigmoid'))

    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

    history = model.fit(train_data, train_labels, epochs=10, batch_size=16, validation_data=(test_data, test_labels))

    _, accuracy = model.evaluate(test_data, test_labels)
    print('Accuracy:', accuracy)

predict()


# In[ ]:





# In[16]:


#

# In[ ]:





# In[ ]:




