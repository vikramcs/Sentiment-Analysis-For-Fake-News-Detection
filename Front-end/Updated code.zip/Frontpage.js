function getEmojiForSentiment(sentimentScore) {
  if (sentimentScore > 0.5) {
    return '🙂'; // Happy emoji for positive sentiment
  } else if (sentimentScore < -0.5) {
    return '😔'; // Sad emoji for negative sentiment
  } else {
    return '😐'; // Neutral emoji for neutral sentiment
  }
}
function analyzeSentiment(text) {
  // Make API request to fetch sentiment score
  // Replace 'API_ENDPOINT' with the actual API endpoint
  return fetch('API_ENDPOINT', {
    method: 'POST',
    body: JSON.stringify({ text: text }),
    headers: {
      'Content-Type': 'application/json',
    },
  })
    .then(response => response.json())
    .then(data => data.sentimentScore)
    .catch(error => {
      console.error('Error:', error);
      // Handle error case
      return 0; // Return a default sentiment score
    });
}

function verifyNews(newsTitle, newsContent) {
  // Make API request to verify news
  // Replace 'API_ENDPOINT' with the actual API endpoint
  return fetch('API_ENDPOINT', {
    method: 'POST',
    body: JSON.stringify({ title: newsTitle, content: newsContent }),
    headers: {
      'Content-Type': 'application/json',
    },
  })
    .then(response => response.json())
    .then(data => data.isNewsFake)
    .catch(error => {
      console.error('Error:', error);
      // Handle error case
      return false; // Return a default value for news verification
    });
}

document.getElementById('analyze-btn').addEventListener('click', function() {
  var newsTitle = document.getElementById('news-title').value;
  var newsContent = document.getElementById('news-content').value;

  if (newsTitle.trim() === '' || newsContent.trim() === '') {
    // Handle empty input
    alert('Please enter news title and content.');
    return;
  }

  analyzeSentiment(newsTitle + ' ' + newsContent)
    .then(sentimentScore => {
      return Promise.all([
        sentimentScore,
        verifyNews(newsTitle, newsContent),
      ]);
    })
    .then(([sentimentScore, isNewsFake]) => {
      var resultContainer = document.getElementById('result-container');
      resultContainer.innerHTML = '';

      var sentimentText = document.createElement('p');
      sentimentText.textContent = 'Sentiment Score: ' + sentimentScore.toFixed(2);

      var sentimentLabel = document.createElement('p');
      if (sentimentScore > 0.5) {
        sentimentLabel.textContent = 'Sentiment: Positive';
        sentimentLabel.classList.add('positive');
      } else if (sentimentScore < -0.5) {
        sentimentLabel.textContent = 'Sentiment: Negative';
        sentimentLabel.classList.add('negative');
      } else {
        sentimentLabel.textContent = 'Sentiment: Neutral';
        sentimentLabel.classList.add('neutral');
      }

      var newsVerification = document.createElement('p');
      if (isNewsFake) {
        newsVerification.textContent = 'News: Fake';
        newsVerification.classList.add('fake');
      } else {
        newsVerification.textContent = 'News: Real';
        newsVerification.classList.add('real');
      }

      resultContainer.appendChild(sentimentText);
      resultContainer.appendChild(sentimentLabel);
      resultContainer.appendChild(newsVerification);
    })
    .catch(error => {
      console.error('Error:', error);
      // Handle error case
    });
});
document.getElementById('login-btn').addEventListener('click', function() {
  window.location.href = 'https://codepen.io/vikram1/full/bGQorjR'; // Replace 'login.html' with the actual login page URL
});

document.getElementById('register-btn').addEventListener('click', function() {
  window.location.href = 'https://codepen.io/vikram1/full/zLKwXL'; // Replace 'register.html' with the actual register page URL
});
document.getElementById('analyze-btn').addEventListener('click', function() {
  var newsTitle = document.getElementById('news-title').value;
  var newsContent = document.getElementById('news-content').value;
  var loadingSpinner = document.getElementById('loading-spinner');

  if (newsTitle.trim() === '' || newsContent.trim() === '') {
    // Handle empty input
    alert('Please enter news title and content.');
    return;
  }

  // Show the spinner before the analysis
  loadingSpinner.style.display = 'block';

  analyzeSentiment(newsTitle + ' ' + newsContent)
    .then(sentimentScore => {
      return Promise.all([
        sentimentScore,
        verifyNews(newsTitle, newsContent),
      ]);
    })
    .then(([sentimentScore, isNewsFake]) => {
      var resultContainer = document.getElementById('result-container');
      resultContainer.innerHTML = '';

      // ... Rest of the code for displaying the analysis results ...

      // Hide the spinner after the analysis is complete
      loadingSpinner.style.display = 'none';
    })
});