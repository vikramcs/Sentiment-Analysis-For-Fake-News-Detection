import pickle
from flask import Flask, request, app, jsonify, url_for, render_template
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import re

app = Flask(__name__)
model = pickle.load(open("logistic-regression-model.pkl", "rb"))
vectorizer = pickle.load(open("vectorizer.pkl", "rb"))


def preprocess_text(text):
    
    #Removing special characters and symbols
    text = re.sub(r"[^a-zA-Z0-9]", " ", text)
    
    #Converting text to lowercase
    text = text.lower()
    
    #Removing extra whitespaces
    text = re.sub(r"\s+", " ", text)
    
    #Other preprocessing steps (if any)
    
    return text


df = pd.read_csv("train_data.csv")

# Data Pre-processing 
df["statement"] = df["statement"].apply(preprocess_text)

# Get data from dataframe (only for testing purpose)
data = df[df["ID"] == "3959.json"]
statement = data["statement"]

vectorized_data = vectorizer.transform(statement)

final_prediction = model.predict(vectorized_data)
print(final_prediction[0])


@app.route('/')
def home():
    return render_template("index.html")


# @app.route("/prediction", request=["POST"])
# def predict():


if __name__ == "__main__":
    app.run(debug=True)