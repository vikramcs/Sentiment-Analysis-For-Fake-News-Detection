document.getElementById('analyze-btn').addEventListener('click', function() {
  var newsTitle = document.getElementById('news-title').value;
  var newsContent = document.getElementById('news-content').value;

  if (newsTitle.trim() === '' || newsContent.trim() === '') {
    // Handle empty input
    alert('Please enter news title and content.');
    return;
  }

  analyzeSentiment(newsTitle + ' ' + newsContent)
    .then(sentimentScore => {
      return Promise.all([
        sentimentScore,
        verifyNews(newsTitle, newsContent),
      ]);
    })
    .then(([sentimentScore, isNewsFake]) => {
      var resultContainer = document.getElementById('result-container');
      resultContainer.innerHTML = '';

      var sentimentText = document.createElement('p');
      sentimentText.textContent = 'Sentiment Score: ' + sentimentScore.toFixed(2);

      var sentimentLabel = document.createElement('p');
      if (sentimentScore > 0.5) {
        sentimentLabel.textContent = 'Sentiment: Positive';
        sentimentLabel.classList.add('positive');
      } else if (sentimentScore < -0.5) {
        sentimentLabel.textContent = 'Sentiment: Negative';
        sentimentLabel.classList.add('negative');
      } else {
        sentimentLabel.textContent = 'Sentiment: Neutral';
        sentimentLabel.classList.add('neutral');
      }

      var newsVerification = document.createElement('p');
      if (isNewsFake) {
        newsVerification.textContent = 'News: Fake';
        newsVerification.classList.add('fake');
      } else {
        newsVerification.textContent = 'News: Real';
        newsVerification.classList.add('real');
      }

      resultContainer.appendChild(sentimentText);
      resultContainer.appendChild(sentimentLabel);
      resultContainer.appendChild(newsVerification);
    })
    .catch(error => {
      console.error('Error:', error);
      // Handle error case
    });
});
document.getElementById('login-btn').addEventListener('click', function() {
  window.location.href = 'https://codepen.io/vikram1/full/bGQorjR'; // Replace 'login.html' with the actual login page URL
});

document.getElementById('register-btn').addEventListener('click', function() {
  window.location.href = 'https://codepen.io/vikram1/full/zLKwXL'; // Replace 'register.html' with the actual register page URL
});
document.getElementById('analyze-btn').addEventListener('click', function() {
  var newsTitle = document.getElementById('news-title').value;
  var newsContent = document.getElementById('news-content').value;
  var loadingSpinner = document.getElementById('loading-spinner');

  if (newsTitle.trim() === '' || newsContent.trim() === '') {
    // Handle empty input
    alert('Please enter news title and content.');
    return;
  }

  // Show the spinner before the analysis
  loadingSpinner.style.display = 'block';

  analyzeSentiment(newsTitle + ' ' + newsContent)
    .then(sentimentScore => {
      return Promise.all([
        sentimentScore,
        verifyNews(newsTitle, newsContent),
      ]);
    })
    .then(([sentimentScore, isNewsFake]) => {
      var resultContainer = document.getElementById('result-container');
      resultContainer.innerHTML = '';

      // ... Rest of the code for displaying the analysis results ...

      // Hide the spinner after the analysis is complete
      loadingSpinner.style.display = 'none';
    })
});
// Add this function to toggle the menu items visibility
function toggleMenuItems() {
  var menuItems = document.getElementById('menu-items');
  menuItems.style.display = (menuItems.style.display === 'block') ? 'none' : 'block';
}
// Add this to your existing JavaScript code
document.addEventListener('DOMContentLoaded', function() {
  var helpIcon = document.getElementById('helpIcon');
  var helpPopup = document.getElementById('helpPopup');
  var closeHelp = document.getElementById('closeHelp');

  // Show the help popup when the user clicks the help icon
  helpIcon.addEventListener('click', function() {
    helpPopup.style.display = 'block';
  });

  // Close the help popup when the user clicks the close button
  closeHelp.addEventListener('click', function() {
    helpPopup.style.display = 'none';
  });
});

// Automatically display the help popup when the page loads
window.addEventListener('load', function() {
  var helpPopup = document.getElementById('helpPopup');
  helpPopup.style.display = 'block';
});
